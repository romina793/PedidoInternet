//
//  ViewController.swift
//  PermisoInternet
//
//  Created by Romina Pozzuto on 13/01/2020.
//  Copyright © 2020 Romina Pozzuto. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var search: UISearchBar!
    
    @IBOutlet weak var textView: UITextView!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        if self.search.text == "" {
            self.textView.text = "Aquí verás el JSON del libro buscado por ISBN"
        }
        self.search.delegate = self
        let gesture = UITapGestureRecognizer(target: self, action: #selector(closeKeyboardType(_:)))
        self.view.addGestureRecognizer(gesture)
    }
    
    func pedidoDeLibro(ISBN: String) -> String {
        let urls = "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:\(ISBN)"
        let url = NSURL(string: urls)
        let datos: NSData? = NSData(contentsOf: url! as URL)
        let text = NSString(data: datos! as Data, encoding: String.Encoding.utf8.rawValue)
        print(text!)
        return text! as String
    }


}

extension ViewController: UISearchBarDelegate{
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        let libroJason = self.pedidoDeLibro(ISBN: self.search.text ?? "")
        self.textView.text = libroJason
       
    }
    
    @objc func closeKeyboardType(_ sender: UITapGestureRecognizer) {
            self.view.endEditing(true)
        }
}
